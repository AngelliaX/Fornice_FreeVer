<?php
namespace tung;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\level\sound\GhastSound as A;
use pocketmine\level\particle\FlameParticle as B;

use pocketmine\block\Block;
use pocketmine\event\block\BlockPlaceEvent; 
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\math\Vector3;
class Main extends PluginBase  implements Listener{
  
  public function onEnable(){
	     $this->getServer()->getPluginManager()->registerEvents($this, $this);
	     $this->getLogger()->info("Fortnice");
  }
  
  public function blockplace(BlockPlaceEvent $event){
     $id = $event->getBlock()->getID();	  
     $block = $event->getBlock();
     $player = $event->getPlayer();
	 $x = $block->getX();
	 $y = $block->getY();
	 $z = $block->getZ();
	 $pos = new Vector3($x,$y,$z);	 
	 $direc = $player->getDirection();
	 
	 $faces = [
	   0=>0,
	   1=>2,
	   2=>1,
	   3=>3,
	 ];
	 $this->meta = $faces[$direc] & 0x03;
	 
	 //Stair-------------------------------------
	 if($id == 163){
      switch ($direc){
       case 1:		  
 	      //floor1
	      $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(1,0,0),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(-1,0,0),Block::get($id,$this->meta));
	      //floor2
	      $player->getLevel()->setBlock($pos->add(0,1,1),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(1,1,1),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(-1,1,1),Block::get($id,$this->meta));
          //floor3
	      $player->getLevel()->setBlock($pos->add(0,2,2),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(1,2,2),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(-1,2,2),Block::get($id,$this->meta));
	      //floor4
	      $player->getLevel()->setBlock($pos->add(0,3,3),Block::get($id,$this->meta));	  
	      $player->getLevel()->setBlock($pos->add(1,3,3),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(-1,3,3),Block::get($id,$this->meta));
	      //Floor
	      $player->getLevel()->setBlock($pos->add(0,3,4),Block::get(5,$this->meta));
	      $player->getLevel()->setBlock($pos->add(1,3,4),Block::get(5,$this->meta));
	 	  $player->getLevel()->setBlock($pos->add(-1,3,4),Block::get(5,$this->meta));
          break;
	   case 0:
	      //floor1
	      $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(0,0,1),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(0,0,-1),Block::get($id,$this->meta));
	      //floor2
	      $player->getLevel()->setBlock($pos->add(1,1,0),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(1,1,1),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(1,1,-1),Block::get($id,$this->meta));
          //floor3
	      $player->getLevel()->setBlock($pos->add(2,2,0),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(2,2,1),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(2,2,-1),Block::get($id,$this->meta));
	      //floor4
	      $player->getLevel()->setBlock($pos->add(3,3,0),Block::get($id,$this->meta));	  
	      $player->getLevel()->setBlock($pos->add(3,3,1),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(3,3,-1),Block::get($id,$this->meta));
	      //Floor
	      $player->getLevel()->setBlock($pos->add(4,3,0),Block::get(5,$this->meta));
	      $player->getLevel()->setBlock($pos->add(4,3,1),Block::get(5,$this->meta));
	 	  $player->getLevel()->setBlock($pos->add(4,3,-1),Block::get(5,$this->meta));	      
          break;   
	   case 2:
	      $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(0,0,1),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(0,0,-1),Block::get($id,$this->meta));
	      //floor2
	      $player->getLevel()->setBlock($pos->add(-1,1,0),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(-1,1,1),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(-1,1,-1),Block::get($id,$this->meta));
          //floor3
	      $player->getLevel()->setBlock($pos->add(-2,2,0),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(-2,2,1),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(-2,2,-1),Block::get($id,$this->meta));
	      //floor4
	      $player->getLevel()->setBlock($pos->add(-3,3,0),Block::get($id,$this->meta));	  
	      $player->getLevel()->setBlock($pos->add(-3,3,1),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(-3,3,-1),Block::get($id,$this->meta));
	      //Floor
	      $player->getLevel()->setBlock($pos->add(-4,3,0),Block::get(5,$this->meta));
	      $player->getLevel()->setBlock($pos->add(-4,3,1),Block::get(5,$this->meta));
	 	  $player->getLevel()->setBlock($pos->add(-4,3,-1),Block::get(5,$this->meta));	      	  
          break;       
	   case 3:
 	      //floor1
	      $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(1,0,0),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(-1,0,0),Block::get($id,$this->meta));
	      //floor2
	      $player->getLevel()->setBlock($pos->add(0,1,-1),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(1,1,-1),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(-1,1,-1),Block::get($id,$this->meta));
          //floor3
	      $player->getLevel()->setBlock($pos->add(0,2,-2),Block::get($id,$this->meta));
          $player->getLevel()->setBlock($pos->add(1,2,-2),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(-1,2,-2),Block::get($id,$this->meta));
	      //floor4
	      $player->getLevel()->setBlock($pos->add(0,3,-3),Block::get($id,$this->meta));	  
	      $player->getLevel()->setBlock($pos->add(1,3,-3),Block::get($id,$this->meta));
	      $player->getLevel()->setBlock($pos->add(-1,3,-3),Block::get($id,$this->meta));
	      //Floor
	      $player->getLevel()->setBlock($pos->add(0,3,-4),Block::get(5,$this->meta));
	      $player->getLevel()->setBlock($pos->add(1,3,-4),Block::get(5,$this->meta));
	 	  $player->getLevel()->setBlock($pos->add(-1,3,-4),Block::get(5,$this->meta));	    
	      break;
	  }
	}
	 //Glass----------------------------------------------
	 
	 if($id == 160){	   
	  /*floor 1*/ 
	  $player->getLevel()->setBlock($pos->add(0,0,2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,2),Block::get($id,$this->meta));
      $player->getLevel()->setBlock($pos->add(1,0,2),Block::get($id,$this->meta));
 	  
	  $player->getLevel()->setBlock($pos->add(0,0,-2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,-2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,-2),Block::get($id,$this->meta));

	  $player->getLevel()->setBlock($pos->add(-2,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-2,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-2,0,-1),Block::get($id,$this->meta));

	  $player->getLevel()->setBlock($pos->add(2,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(2,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(2,0,-1),Block::get($id,$this->meta));

      $player->getLevel()->setBlock($pos->add(2,0,2),Block::get($id,$this->meta)); 	  
	  $player->getLevel()->setBlock($pos->add(-2,0,2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(2,0,-2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-2,0,-2),Block::get($id,$this->meta));
	  /*floor 2*/
	  
	  $player->getLevel()->setBlock($pos->add(0,1,2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,1,2),Block::get($id,$this->meta));
      $player->getLevel()->setBlock($pos->add(1,1,2),Block::get($id,$this->meta));
 	  
	  $player->getLevel()->setBlock($pos->add(0,1,-2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,1,-2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,1,-2),Block::get($id,$this->meta));

	  $player->getLevel()->setBlock($pos->add(-2,1,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-2,1,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-2,1,-1),Block::get($id,$this->meta));

	  $player->getLevel()->setBlock($pos->add(2,1,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(2,1,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(2,1,-1),Block::get($id,$this->meta));

      $player->getLevel()->setBlock($pos->add(2,1,2),Block::get($id,$this->meta)); 	  
	  $player->getLevel()->setBlock($pos->add(-2,1,2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(2,1,-2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-2,1,-2),Block::get($id,$this->meta));	   
	   }	
	 //Iron------------------------------
	 if($id == 101){
	  switch($direc){
       case 1:		  
	     $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(1,0,0),Block::get($id,$this->meta));
	     $player->getLevel()->setBlock($pos->add(-1,0,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,1,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(1,1,0),Block::get($id,$this->meta));
	     $player->getLevel()->setBlock($pos->add(-1,1,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,2,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(1,2,0),Block::get($id,$this->meta));
		 $player->getLevel()->setBlock($pos->add(-1,2,0),Block::get($id,$this->meta));
	     break;		 
       case 3:		  
	     $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(1,0,0),Block::get($id,$this->meta));
	     $player->getLevel()->setBlock($pos->add(-1,0,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,1,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(1,1,0),Block::get($id,$this->meta));
	     $player->getLevel()->setBlock($pos->add(-1,1,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,2,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(1,2,0),Block::get($id,$this->meta));
		 $player->getLevel()->setBlock($pos->add(-1,2,0),Block::get($id,$this->meta));
	     break;		 		 
	   case 0:
	     $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,0,-1),Block::get($id,$this->meta));
	     $player->getLevel()->setBlock($pos->add(0,0,1),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,1,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,1,1),Block::get($id,$this->meta));
	     $player->getLevel()->setBlock($pos->add(0,1,-1),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,2,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,2,-1),Block::get($id,$this->meta));
	     $player->getLevel()->setBlock($pos->add(0,2,1),Block::get($id,$this->meta)); 	  	  	  
	     break;
	   case 2:
	     $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,0,-1),Block::get($id,$this->meta));
	     $player->getLevel()->setBlock($pos->add(0,0,1),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,1,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,1,1),Block::get($id,$this->meta));
	     $player->getLevel()->setBlock($pos->add(0,1,-1),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,2,0),Block::get($id,$this->meta)); 
	     $player->getLevel()->setBlock($pos->add(0,2,-1),Block::get($id,$this->meta));
	     $player->getLevel()->setBlock($pos->add(0,2,1),Block::get($id,$this->meta)); 	  	  	  
	     break;	  
	  }
	 }
	 //Bang 
   if($id == 241){
	 switch($direc){	
      case 1:
	  $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(0,0,1),Block::get($id,$this->meta));	  
      $player->getLevel()->setBlock($pos->add(0,0,2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(0,0,3),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,3),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,3),Block::get($id,$this->meta));
	  break;
	 case 3:
	  $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,-1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,-1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(0,0,-1),Block::get($id,$this->meta));	  
      $player->getLevel()->setBlock($pos->add(0,0,-2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,-2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,-2),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(0,0,-3),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,-3),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,-3),Block::get($id,$this->meta));
      break;
	 case 2:
	  $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(0,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(0,0,-1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-1,0,-1),Block::get($id,$this->meta));	  
      $player->getLevel()->setBlock($pos->add(-2,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-2,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-2,0,-1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-3,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-3,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(-3,0,-1),Block::get($id,$this->meta));
      break;
	 case 0:
	  $player->getLevel()->setBlock($pos->add(0,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(0,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(0,0,-1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(1,0,-1),Block::get($id,$this->meta));	  
      $player->getLevel()->setBlock($pos->add(2,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(2,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(2,0,-1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(3,0,0),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(3,0,1),Block::get($id,$this->meta));
	  $player->getLevel()->setBlock($pos->add(3,0,-1),Block::get($id,$this->meta));	 
	  break;
	 }
   }     
  }	 
}
